
public class SeleniumDemo {
    public static void main(String[] args) {
    	
    	//Chrome web 
    	ChromeWeb.ChromeWebTestTitle();

    	//Firefox web
    	FirefoxWeb.FirefoxWebTestTitle();
    	
    }//END OF MAIN CLASS
}
